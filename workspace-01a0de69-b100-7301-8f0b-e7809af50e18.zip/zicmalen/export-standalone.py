"""Build with npm run build first, then run this script."""
from pathlib import Path
import re, base64, mimetypes
root=Path(__file__).parent
built=root/'dist'
html=(built/'index.html').read_text()
def data_uri(path):
    mime=mimetypes.guess_type(str(path))[0] or 'application/octet-stream'
    return f'data:{mime};base64,'+base64.b64encode(path.read_bytes()).decode()
css='\n'.join(p.read_text() for p in (built/'assets').glob('*.css'))
js='\n'.join(p.read_text() for p in (built/'assets').glob('*.js'))
for p in (root/'public').rglob('*'):
    if p.is_file():
        old='/'+p.relative_to(root/'public').as_posix()
        uri=data_uri(p)
        html=html.replace(old,uri)
        css=css.replace(old,uri)
        js=js.replace(old,uri)
html=re.sub(r'<script type="module"[^>]*src="[^"]+"[^>]*></script>','',html)
html=re.sub(r'<link rel="stylesheet"[^>]*>','',html)
html=html.replace('</head>','<style>'+css+'</style></head>')
html=html.replace('</body>','<script type="module">'+js.replace('</script','<\\/script')+'</script></body>')
out=root/'Zicmalen-Web-built.html'
out.write_text(html)
print(f'Created {out.name} ({out.stat().st_size:,} bytes)')
