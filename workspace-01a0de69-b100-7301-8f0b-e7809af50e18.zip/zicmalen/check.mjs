// Compatibility entry point for the redesigned site's browser checks.
import './tests/verify.mjs';
