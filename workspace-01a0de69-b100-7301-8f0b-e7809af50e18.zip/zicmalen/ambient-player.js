// Original, self-hosted ambient audio. Audible autoplay is attempted, never bypassed.
export function initAmbientMusic(config) {
  if (!config?.enabled || !config.src) return;
  const svg = paths => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths}</svg>`;
  const soundIcon = svg('<path d="M11 5 6 9H3v6h3l5 4V5Z"/><path d="M15 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/>');
  const mutedIcon = svg('<path d="M11 5 6 9H3v6h3l5 4V5Z"/><path d="m16 9 5 6m0-6-5 6"/>');
  const chevronIcon = svg('<path d="m8 14 4-4 4 4"/>');
  const v = Number(config.defaultVolume);
  const initialVolume = Number.isFinite(v) ? Math.max(0, Math.min(1, v)) : 0.20;
  const audio = document.createElement('audio');
  audio.id = 'ambient-audio';
  audio.loop = true;
  audio.preload = config.autoplay ? 'auto' : 'none';
  audio.setAttribute('aria-hidden', 'true');
  const shell = document.createElement('div');
  shell.className = 'ambient-player compact';
  shell.innerHTML = `<div class="music-panel" id="music-panel" role="region" aria-label="Background music settings" hidden>
    <div class="music-panel-heading"><span class="music-panel-label">AUDIO / AMBIENT</span><button type="button" class="music-panel-close" aria-label="Close music settings">${svg('<path d="m6 6 12 12M18 6 6 18"/>')}</button></div>
    <h3 class="music-track-title"></h3><p class="music-track-description"></p>
    <label class="music-volume-label" for="music-volume"><span>${soundIcon} Volume</span><output id="music-volume-value" for="music-volume">${Math.round(initialVolume*100)}%</output></label>
    <input type="range" id="music-volume" min="0" max="100" step="1" value="${Math.round(initialVolume*100)}" aria-label="Background music volume" aria-valuetext="${Math.round(initialVolume*100)} percent">
    <p class="music-settings-note">Soft, original sound. Pauses when you leave this tab.</p>
    <p id="music-feedback" class="music-feedback" role="status" hidden></p>
  </div>
  <div class="music-dock"><button class="music-toggle" id="music-toggle" type="button" aria-label="Play background music" title="Play background music" aria-pressed="false" aria-controls="ambient-audio"><span class="music-action-icon">${mutedIcon}</span><span class="music-toggle-label visually-hidden">Sound off</span></button><button class="music-settings" id="music-settings" type="button" aria-label="Open music settings" title="Music volume" aria-expanded="false" aria-controls="music-panel">${chevronIcon}</button></div>`;
  shell.querySelector('.music-track-title').textContent = config.title || 'Background music';
  shell.querySelector('.music-track-description').textContent = config.description || 'Original ambient soundtrack';
  document.body.append(audio, shell);
  const toggle = shell.querySelector('#music-toggle');
  const settings = shell.querySelector('#music-settings');
  const panel = shell.querySelector('#music-panel');
  const slider = shell.querySelector('#music-volume');
  const feedback = shell.querySelector('#music-feedback');
  const actionIcon = shell.querySelector('.music-action-icon');
  const label = shell.querySelector('.music-toggle-label');
  const output = shell.querySelector('#music-volume-value');
  let volume = initialVolume;
  let context = null;
  let gain = null;
  let pending = false;
  let confirmedPlaying = false;
  let attempt = 0;
  let fadeFrame = null;
  let blocked = false;

  function ensureAudioGraph() {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx || context) return;
    context = new AudioCtx();
    const source = context.createMediaElementSource(audio);
    gain = context.createGain();
    gain.gain.value = volume;
    source.connect(gain);
    gain.connect(context.destination);
    audio.volume = 1;
  }
  function applyVolume(fade = false) {
    cancelAnimationFrame(fadeFrame);
    if (gain && context) {
      const now = context.currentTime;
      gain.gain.cancelScheduledValues(now);
      gain.gain.setValueAtTime(gain.gain.value, now);
      if (fade) gain.gain.linearRampToValueAtTime(volume, now + 0.8);
      else gain.gain.setTargetAtTime(volume, now, 0.03);
      audio.volume = 1;
    } else if (fade && !audio.paused) {
      const start = performance.now();
      // Autoplay uses the native media element, so a suspended AudioContext cannot
      // leave it reporting "playing" while producing no audio.
      const from = Math.min(audio.volume, volume);
      const tick = now => {
        const progress = Math.min((now-start)/800, 1);
        audio.volume = from + (volume-from)*progress;
        if (progress < 1 && !audio.paused) fadeFrame = requestAnimationFrame(tick);
      };
      fadeFrame = requestAnimationFrame(tick);
    } else audio.volume = volume;
  }
  function updateUI() {
    const active = !audio.paused && confirmedPlaying;
    const audible = active && !audio.muted && volume > 0;
    shell.classList.toggle('is-playing', audible);
    shell.dataset.autoplay = blocked ? 'blocked' : active ? 'playing' : 'idle';
    toggle.setAttribute('aria-pressed', String(audible));
    toggle.setAttribute('aria-busy', String(pending));
    const action = pending ? 'Cancel loading background music' : audible ? 'Mute background music' : blocked ? 'Play background music — browser blocked autoplay' : active && volume === 0 ? 'Unmute background music' : 'Play background music';
    toggle.setAttribute('aria-label', action);
    toggle.title = action;
    actionIcon.innerHTML = audible ? soundIcon : mutedIcon;
    label.textContent = pending ? 'Loading' : audible ? 'Music on' : 'Sound off';
  }
  function openSettings(open) {
    panel.hidden = !open;
    settings.setAttribute('aria-expanded', String(open));
    settings.setAttribute('aria-label', open ? 'Close music settings' : 'Open music settings');
  }
  function pause() {
    attempt += 1;
    cancelAnimationFrame(fadeFrame);
    audio.muted = true;
    audio.pause();
    confirmedPlaying = false;
    pending = false;
    updateUI();
  }
  function showError(open = true) {
    feedback.textContent = 'Audio could not start. Tap the speaker to try again, or continue with sound off.';
    feedback.hidden = false;
    if (open) openSettings(true);
  }
  async function startPlayback(fromGesture = false) {
    if (document.hidden) return;
    const request = ++attempt;
    feedback.hidden = true;
    blocked = false;
    pending = true;
    audio.muted = false;
    updateUI();
    if (!audio.getAttribute('src')) audio.src = config.src;
    try {
      // A gain node is established only from an explicit gesture. Native autoplay
      // follows browser policy without Web Audio unlocking tricks or global click hooks.
      if (fromGesture) ensureAudioGraph();
      if (gain) {
        gain.gain.setValueAtTime(0, context.currentTime);
        audio.volume = 1;
      } else audio.volume = Math.min(volume, 0.035);
      const resuming = context && context.state !== 'running' ? context.resume() : Promise.resolve();
      const playing = audio.play();
      await Promise.all([resuming, playing]);
      if (request !== attempt) return;
      if (document.hidden) { pause(); return; }
      pending = false;
      confirmedPlaying = true;
      applyVolume(true);
      updateUI();
    } catch (error) {
      if (request !== attempt) return;
      pending = false;
      confirmedPlaying = false;
      audio.pause();
      if (error.name === 'NotAllowedError') {
        blocked = true;
        feedback.textContent = 'Your browser blocks automatic sound. Tap the speaker to start the music.';
        feedback.hidden = false;
        // Do not interrupt the site with a popup or pretend blocked audio is playing.
      } else if (error.name !== 'AbortError') showError(fromGesture);
      updateUI();
    }
  }
  toggle.addEventListener('click', () => {
    if (pending || (!audio.paused && volume > 0 && !audio.muted)) { pause(); return; }
    if (volume === 0) {
      volume = initialVolume || 0.20;
      slider.value = String(Math.round(volume*100));
      output.value = `${slider.value}%`;
      slider.setAttribute('aria-valuetext', `${slider.value} percent`);
      if (!audio.paused) { audio.muted = false; applyVolume(); updateUI(); return; }
    }
    void startPlayback(true);
  });
  audio.addEventListener('playing', () => {
    if (document.hidden || audio.muted) { pause(); return; }
    confirmedPlaying = true;
    pending = false;
    updateUI();
  });
  audio.addEventListener('pause', () => { confirmedPlaying = false; updateUI(); });
  audio.addEventListener('error', () => { pause(); showError(false); });
  slider.addEventListener('input', () => {
    volume = Number(slider.value)/100;
    output.value = `${slider.value}%`;
    slider.setAttribute('aria-valuetext', `${slider.value} percent`);
    // The slider is also an explicit gesture, enabling gain-based volume on iOS.
    // Changing it never starts a blocked or manually muted media element.
    try {
      ensureAudioGraph();
      if (context && context.state !== 'running') context.resume().catch(() => {});
    } catch { /* Native media volume remains available where supported. */ }
    applyVolume();
    updateUI();
  });
  settings.addEventListener('click', () => openSettings(panel.hidden));
  shell.querySelector('.music-panel-close').addEventListener('click', () => { openSettings(false); settings.focus(); });
  document.addEventListener('click', event => {
    if (!panel.hidden && !event.composedPath().includes(shell)) openSettings(false);
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && !panel.hidden) {
      const hadFocus = shell.contains(document.activeElement);
      openSettings(false);
      if (hadFocus) settings.focus();
    }
  });
  document.addEventListener('visibilitychange', () => { if (document.hidden) pause(); });
  window.addEventListener('pagehide', pause);
  updateUI();
  if (config.autoplay) void startPlayback(false);
}
