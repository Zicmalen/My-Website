export const siteConfig = {
  name: 'Zicmalen Web-built',
  founder: 'Isaac Richard',
  email: 'Zicmalen@gmail.com',
  phoneDisplay: '+234 708 091 1672',
  whatsapp: '2347080911672',
  // Optional social accounts. Add complete verified HTTPS URLs; empty entries stay hidden.
  socials: { github: '', linkedin: '', instagram: '' },
  music: {
    enabled: true,
    src: '/audio/quiet-circuit.mp3',
    title: 'Quiet Circuit',
    description: 'Original ambient electronic loop',
    defaultVolume: 0.20,
    autoplay: true,
    // Attempts soft playback on load. Browsers may require a tap first.
  },
  contact: {
    // Frontend defaults to a message preview and the user's own email app.
    // Optional HTTPS/same-origin endpoint accepting JSON via POST.
    // Return { "success": true } only after your email provider accepts the message.
    // Never put private email-service keys in this frontend configuration.
    endpoint: '',
  },
};
