// Network-mocked integration test. This does not send any real emails.
import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
const b=await chromium.launch();const p=await b.newPage({reducedMotion:'reduce'});
await p.route('**/site-config.js*',async route=>{const original=await route.fetch();await route.fulfill({response:original,body:(await original.text()).replace("endpoint: ''","endpoint: '/api/contact'")});});
let received;
await p.route('**/api/contact',async route=>{received=route.request().postDataJSON();await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({success:true})});});
await p.goto(process.env.SITE_URL||'http://localhost:5173');
await p.locator('#name').fill('Adapter Test');await p.locator('#email').fill('test@example.com');await p.locator('#phone').fill('+234 700 000 0000');await p.locator('#service-select').selectOption('Website Development');await p.locator('#message').fill('Testing the optional email adapter with a mocked provider only.');await p.locator('.form-submit').click();
await p.locator('#confirm-send').click();await p.getByText('Accepted by email service',{exact:true}).waitFor();assert.equal(received.name,'Adapter Test');assert.equal(received.service,'Website Development');
await p.locator('.modal-close').click();
await p.route('**/api/contact',async route=>route.fulfill({status:500,contentType:'application/json',body:'{"success":false}'}));
await p.locator('.form-submit').click();await p.locator('#confirm-send').click();await p.getByText('Try again',{exact:true}).waitFor();assert((await p.locator('#delivery-status').textContent()).includes('not been confirmed'));
console.log('Optional email adapter: mocked acceptance and failure paths passed. No real emails sent.');await b.close();
