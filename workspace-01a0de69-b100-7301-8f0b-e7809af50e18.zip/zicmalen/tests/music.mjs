import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
const url=process.env.SITE_URL||'http://localhost:5173';
for(const policy of ['user-gesture-required','no-user-gesture-required']){
 const browser=await chromium.launch({args:[`--autoplay-policy=${policy}`]});
 const page=await browser.newPage({viewport:{width:390,height:844},reducedMotion:'reduce'});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(url);
 const audio=page.locator('#ambient-audio');
 assert.equal(await audio.getAttribute('src'),'/audio/quiet-circuit.mp3');
 assert.equal(await page.locator('#music-volume').inputValue(),'20');
 if(policy==='user-gesture-required'){
  await page.waitForFunction(()=>document.querySelector('.ambient-player').dataset.autoplay==='blocked');
  assert.equal(await audio.evaluate(a=>a.paused),true);
  assert.equal(await page.locator('#music-toggle').getAttribute('aria-pressed'),'false');
  assert((await page.locator('#music-toggle').getAttribute('aria-label')).includes('browser blocked autoplay'));
  await page.locator('#music-toggle').click();
 } else {
  // No click or other user gesture before this assertion.
  await page.waitForFunction(()=>document.querySelector('#ambient-audio').currentTime>0.15);
  assert.equal(await page.locator('#music-toggle').getAttribute('aria-pressed'),'true');
 }
 await page.waitForFunction(()=>!document.querySelector('#ambient-audio').paused&&document.querySelector('#ambient-audio').currentTime>0.2);
 assert.equal(await page.locator('#music-toggle').getAttribute('aria-label'),'Mute background music');
 assert.equal(await audio.evaluate(a=>a.loop),true);
 await page.locator('#music-toggle').click();
 assert.equal(await audio.evaluate(a=>a.paused&&a.muted),true);
 assert.equal(await page.locator('#music-toggle').getAttribute('aria-pressed'),'false');
 await page.locator('#music-settings').click();
 assert(await page.locator('#music-panel').isVisible());
 await page.locator('#music-volume').fill('12');
 assert.equal(await page.locator('#music-volume-value').textContent(),'12%');
 assert.equal(await audio.evaluate(a=>a.paused),true);
 await page.keyboard.press('Escape');
 await page.locator('#music-toggle').click();
 await page.waitForFunction(()=>!document.querySelector('#ambient-audio').paused);
 await page.locator('#music-toggle').click();
 assert.equal(await audio.evaluate(a=>a.paused),true);
 await page.reload();
 if(policy==='no-user-gesture-required')await page.waitForFunction(()=>!document.querySelector('#ambient-audio').paused);
 for(const width of [320,375,390,700,701,730,750,768,1440]){
  await page.setViewportSize({width,height:844});
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),`overflow ${width}`);
  const dock=await page.locator('.music-dock').boundingBox();assert(dock.width<=75,'sound control should be compact');
 }
 assert(!(await page.content()).includes('Zicmalen Bireaz'));
 assert((await page.title()).includes('Zicmalen Web-built'));
 assert.equal(await page.locator('.contact-details a[href^="mailto:"]').getAttribute('href'),'mailto:Zicmalen@gmail.com');
 assert.deepEqual(errors,[]);
 console.log(`PASS ${policy}: correct autoplay behavior, honest state, compact mute, resume and volume; no JS errors or responsive overflow.`);
 if(policy==='user-gesture-required'){
  await page.setViewportSize({width:390,height:844});await page.screenshot({path:'/home/user/checks/web-built-mobile.png'});
  await page.setViewportSize({width:1440,height:1000});await page.screenshot({path:'/home/user/checks/web-built-desktop.png'});
 }
 await browser.close();
}
