import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const url=process.env.SITE_URL||'http://localhost:5173';
const browser=await chromium.launch();
const page=await browser.newPage({viewport:{width:1440,height:1000},reducedMotion:'reduce'});
const errors=[];page.on('pageerror',e=>errors.push(e.message));
const results=[];
await page.goto(url);await page.evaluate(()=>document.fonts.ready);
assert.equal(await page.title(),'Zicmalen Web-built | Web Development, Digital Solutions & AI');
assert.equal(await page.locator('h1').count(),1);
assert.equal(await page.locator('.project-card').count(),5);
assert.equal(await page.locator('.service-card').count(),6);
assert.equal(await page.locator('.stack-card').count(),8);
assert.equal(await page.locator('.benefit').count(),8);
assert.equal(await page.locator('.testimonial').count(),3);
assert.equal(await page.locator('.pricing-card').count(),3);
assert.equal(await page.locator('#social-links').isVisible(),false);
results.push('All required sections, 5 projects, 6 services, 8 tools/capabilities, 3 preserved sample reviews, 3 packages present.');
for(const [filter,count] of [['web',3],['ui',1],['ai',1],['all',5]]){await page.locator(`[data-filter="${filter}"]`).click();assert.equal(await page.locator('.project-card:visible').count(),count);assert.equal(await page.locator(`[data-filter="${filter}"]`).getAttribute('aria-pressed'),'true');}
results.push('Portfolio category filters and pressed states passed.');
for(const id of ['zicmalen','food','city','nevada','ai']){await page.locator(`[data-project="${id}"]`).click();assert(await page.locator('#modal').isVisible());assert(await page.locator('#modal-title').textContent());await page.keyboard.press('Escape');assert(!(await page.locator('#modal').isVisible()));}
await page.locator('[data-project="ai"]').click();await page.locator('#similar-project').click();assert.equal(await page.locator('#service-select').inputValue(),'AI Solutions');
await page.locator('[data-service="Professional Package"]').click();assert.equal(await page.locator('#service-select').inputValue(),'Professional Package');
results.push('All five project dialogs, Escape dismissal, focus restoration, project/package preselection passed.');
await page.locator('#name').fill('QA Example');await page.locator('#email').fill('qa@example.com');await page.locator('#phone').fill('+234 700 000 0000');await page.locator('#business').fill('QA Business');await page.locator('#message').fill('I need a responsive website for a small business with a clear contact flow.');
await page.locator('.form-submit').click();assert(await page.locator('.draft-preview').isVisible());
const draft=await page.locator('.draft-preview').textContent();assert(draft.includes('has not been sent'));assert(draft.includes('QA Business'));assert(draft.includes('+234 700 000 0000'));
const mail=await page.locator('#email-draft').getAttribute('href');assert(mail.startsWith('mailto:Zicmalen@gmail.com?'));assert(decodeURIComponent(mail).includes('QA Example'));
const wa=await page.locator('#modal a[href^="https://wa.me/"]').getAttribute('href');assert(wa.startsWith('https://wa.me/2347080911672?text='));
assert.equal(await page.locator('#confirm-send').count(),0);
const downloadPromise=page.waitForEvent('download');await page.locator('#download-draft').click();assert.equal((await downloadPromise).suggestedFilename(),'zicmalen-project-enquiry.txt');
await page.locator('.modal-close').click();results.push('Form validation/review, recipient, encoded email/WhatsApp draft, honest delivery notice, and download passed.');
await page.locator('#phone').fill('1234567');await page.locator('#name').fill('   ');await page.locator('.form-submit').click();assert(await page.locator('#form-error').isVisible());assert(!(await page.locator('#modal').isVisible()));
results.push('Whitespace-only name rejected.');
const allDirectWA=await page.locator('a[href^="https://wa.me/"]').evaluateAll(links=>links.map(a=>a.getAttribute('href')));assert(allDirectWA.every(href=>href.startsWith('https://wa.me/2347080911672')));
assert.equal(await page.locator('a[href="tel:+2347080911672"]').count(),1);
const linkProblems=await page.evaluate(()=>[...document.querySelectorAll('a[href^="#"]')].filter(a=>!document.querySelector(a.getAttribute('href'))).map(a=>a.outerHTML));assert.equal(linkProblems.length,0);
const missingImages=await page.evaluate(async()=>{const imgs=[...document.images];await Promise.all(imgs.map(im=>im.decode().catch(()=>{})));return imgs.filter(im=>!im.naturalWidth).map(im=>im.src);});assert.deepEqual(missingImages,[]);
results.push('All local anchors, WhatsApp/phone/email links, and images verified.');
await page.locator('#privacy-button').click();assert(await page.locator('#modal-title').textContent()==='Private by default.');await page.keyboard.press('Escape');
for(const width of [320,360,375,390,430,650,700,768,820,900,1024,1280,1440,1920]){
 await page.setViewportSize({width,height:1000});
 const dimensions=await page.evaluate(()=>({w:innerWidth,scroll:document.documentElement.scrollWidth}));assert(dimensions.scroll<=dimensions.w,`Overflow at ${width}: ${JSON.stringify(dimensions)}`);
}
results.push('No horizontal overflow at 14 screen widths from 320px to 1920px.');
await page.setViewportSize({width:390,height:844});await page.evaluate(()=>window.scrollTo(0,0));
await page.locator('.menu-toggle').click();assert.equal(await page.locator('.menu-toggle').getAttribute('aria-expanded'),'true');await page.locator('#navigation a[href="#about"]').click();assert(!(await page.locator('#navigation').isVisible()));
await page.locator('.menu-toggle').click();await page.keyboard.press('Escape');assert.equal(await page.locator('.menu-toggle').getAttribute('aria-expanded'),'false');results.push('Mobile menu toggle, navigation and Escape dismissal passed.');
fs.mkdirSync('tests/screenshots',{recursive:true});
for(const width of [390,1440]){
 await page.setViewportSize({width,height:width===390?844:1000});
 for(const id of ['home','portfolio','about','services','technologies','capabilities','testimonials','pricing','contact']){
  await page.locator(`#${id}`).scrollIntoViewIfNeeded();await page.evaluate(()=>document.fonts.ready);
  await page.locator(`#${id}`).screenshot({path:`tests/screenshots/${width}-${id}.png`});
 }
}
assert.deepEqual(errors,[]);results.push('All 9 main sections captured at mobile and desktop; no JavaScript errors.');
console.log(results.join('\n'));fs.writeFileSync('tests/verification-results.txt',results.join('\n')+'\n');await browser.close();
