"""Synthesize an original, sample-free 48-second ambient loop for Zicmalen Web-built.
Requires numpy and soundfile. No third-party recordings or melodies are used.
"""
from pathlib import Path
import numpy as np
import soundfile as sf

SR = 44100
SECONDS = 48
N = SR * SECONDS
mix = np.zeros((N, 2), dtype=np.float64)

def hz(midi):
    return 440 * 2 ** ((midi - 69) / 12)

def add(signal, start, pan=0.0, level=1.0):
    # Circular overlap-add: natural pad and delay tails continue across the loop seam.
    pos = (np.arange(len(signal)) + round(start * SR)) % N
    left = np.cos((pan + 1) * np.pi / 4)
    right = np.sin((pan + 1) * np.pi / 4)
    np.add.at(mix[:, 0], pos, signal * left * level)
    np.add.at(mix[:, 1], pos, signal * right * level)

def pad(midi, phase):
    duration = 16
    t = np.arange(int(duration * SR)) / SR
    attack = np.sin(np.minimum(t / 3.2, 1) * np.pi / 2) ** 2
    release = np.sin(np.minimum((duration - t) / 4.8, 1) * np.pi / 2) ** 2
    freq = hz(midi)
    tone = (np.sin(2*np.pi*freq*t+phase)
            + .24*np.sin(2*np.pi*(freq*1.0014)*t+phase+.3)
            + .16*np.sin(2*np.pi*(freq*.9987)*t+phase+.8)
            + .09*np.sin(2*np.pi*(freq*2)*t+phase))
    movement = .87 + .13*np.sin(2*np.pi*.085*t+phase)
    return tone * attack * release * movement

# Soft ninth-chord voicings, slow harmonic rhythm, no percussion.
chords = [[50,57,60,64,65], [46,53,57,60,62], [45,52,55,60,65], [48,55,60,62,64]]
for c, notes in enumerate(chords):
    for v, note in enumerate(notes):
        add(pad(note, v*.79+c*.33), c*12-2, pan=(v-2)*.31, level=.065 if v < 3 else .047)
    # A quiet, rounded root beneath each chord.
    t = np.arange(16*SR) / SR
    root = np.sin(2*np.pi*hz(notes[0]-12)*t)
    env = np.sin(np.minimum(t/4,1)*np.pi/2)**2 * np.sin(np.minimum((16-t)/5,1)*np.pi/2)**2
    add(root*env, c*12-2, level=.052)

# Sparse glass-like notes; each is original procedural synthesis, not a sample.
sequence = [(3.2,76),(8.1,69),(15.4,74),(21.0,72),(27.5,76),(32.3,79),(39.2,74),(44.0,72)]
for i,(start,note) in enumerate(sequence):
    t = np.arange(7*SR)/SR
    f = hz(note)
    attack = 1-np.exp(-t*13)
    tone = np.sin(2*np.pi*f*t)*np.exp(-t/1.6) + .11*np.sin(2*np.pi*2*f*t)*np.exp(-t/.75)
    sound=tone*attack*np.minimum((7-t)/.7,1)
    pan = -.48 if i%2==0 else .48
    add(sound,start,pan,level=.021)
    add(sound,start+.64,-pan,level=.009)
    add(sound,start+1.31,pan*.65,level=.004)

# Gentle circular stereo diffusion. Preserve dynamics and leave ample headroom.
dry = mix.copy()
for delay, gain in [(.173,.10),(.317,.075),(.571,.04)]:
    mix += np.roll(dry[:, ::-1], round(delay*SR), axis=0)*gain
mix *= .24 / max(np.max(np.abs(mix)), 1e-9)
root=Path(__file__).resolve().parents[1]
path=root/'public/audio/quiet-circuit.mp3'
sf.write(path, mix.astype(np.float32), SR, format='MP3', subtype='MPEG_LAYER_III', bitrate_mode='VARIABLE', compression_level=.6)
print(f'{path.name}: {SECONDS}s stereo; peak {np.max(np.abs(mix)):.3f}; RMS {np.sqrt(np.mean(mix*mix)):.3f}; {path.stat().st_size:,} bytes')
