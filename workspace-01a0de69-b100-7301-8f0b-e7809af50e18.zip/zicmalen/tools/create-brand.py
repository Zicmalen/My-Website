"""Clean, editable vector construction of the user's selected digital W/Z logo.
The shapes retain the selected circuit-glyph silhouette without raster noise.
"""
from pathlib import Path
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

root=Path(__file__).resolve().parents[1]
out=root/'public/brand'
out.mkdir(parents=True,exist_ok=True)
# Routed geometric paths: two blue diagonals, a white return path, and a cyan terminal.
shapes={
 'white-left':[(392,421),(424,557),(440,520),(415,473),(414,452),(408,452),(408,433),(429,433),(429,452),(423,452),(423,469),(446,511),(462,482),(441,421)],
 'white-right':[(576,359),(709,359),(648,506),(605,506),(592,538),(628,538),(628,525),(663,525),(663,560),(628,560),(628,546),(589,546),(562,611),(505,611),(491,573),(514,527),(533,576),(547,541),(526,503),(530,495),(551,532),(578,468),(621,468),(649,400),(556,400)],
 'blue-left':[(316,359),(394,359),(410,400),(365,400),(409,584),(462,482),(421,359),(465,359),(488,432),(524,359),(552,359),(389,668)],
 'blue-bottom':[(545,421),(568,421),(479,594),(491,631),(626,631),(639,598),(682,598),(654,668),(463,668),(453,643),(440,668),(414,668)],
}
def path(points):
 return 'M'+' '.join(f'{x-302},{y-345}' for x,y in points)+'Z'

def mark(primary,accent,node):
 return ''.join(f'<path fill="{primary if name.startswith("white") else accent}" d="{path(points)}"/>' for name,points in shapes.items())+f'<path fill="{node}" d="M334 188h18v18h-18z"/>'

# Outline the actual website typeface for a portable, font-independent wordmark.
font=TTFont(root/'public/fonts/space-grotesk-700.ttf')
glyphs=font.getGlyphSet();cmap=font.getBestCmap();upm=font['head'].unitsPerEm
pen=SVGPathPen(glyphs);advance=0
for char in 'Zicmalen Web-built':
 glyph=glyphs[cmap[ord(char)]]
 glyph.draw(TransformPen(pen,(1,0,0,1,advance,0)))
 advance += glyph.width
scale=110/upm
word_width=advance*scale
horizontal_width=round(457+word_width+22)
for name,primary,accent,node in [
 ('wz-white-blue','#f4f8ff','#0397dd','#00c6cc'),
 ('wz-blue','#377dff','#0397dd','#5bdded'),
 ('wz-white','#ffffff','#ffffff','#ffffff'),
 ('wz-black','#080c12','#080c12','#080c12'),
]:
 title='<title>Zicmalen Web-built — digital W/Z circuit monogram</title>'
 content=mark(primary,accent,node)
 svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 420 340" role="img">{title}{content}</svg>'
 (out/f'{name}.svg').write_text(svg)
 word=f'<path fill="{primary}" transform="translate(457 212) scale({scale} {-scale})" d="{pen.getCommands()}"/>'
 horizontal=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {horizontal_width} 340" role="img">{title}{content}{word}</svg>'
 (out/f'{name}-horizontal.svg').write_text(horizontal)
 if name=='wz-white-blue':
  (out/'wz-horizontal.svg').write_text(horizontal)
  # Fully vector presentation of one final logo, on the site's dark background.
  presentation=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {horizontal_width+160} 500" role="img">{title}<rect width="100%" height="100%" fill="#080c12"/><g transform="translate(80 80)">{content}{word}</g></svg>'
  (root.parent/'Zicmalen-Web-built-Digital-Logo.svg').write_text(presentation)
  # Square social/avatar variant, preserving breathing room around the glyph.
  social=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" role="img">{title}<rect width="512" height="512" rx="72" fill="#080c12"/><g transform="translate(66 102) scale(.905)">{content}</g></svg>'
  (out/'wz-social.svg').write_text(social)
  (root/'public/favicon.svg').write_text(social)
print('Digital W/Z vectors written, with outlined wordmarks and social avatar.')
