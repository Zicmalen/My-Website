import {chromium} from '@playwright/test';
import path from 'node:path';
import fs from 'node:fs';
const base=process.env.SITE_URL||'http://localhost:5173';
const browser=await chromium.launch();
const page=await browser.newPage({viewport:{width:1200,height:760},deviceScaleFactor:1,reducedMotion:'reduce'});
fs.mkdirSync('tests/screenshots',{recursive:true});
for(const id of ['food','city','nevada','ai']){
 await page.goto(`${base}/project-studies/${id}.html`);await page.evaluate(()=>document.fonts.ready);await page.screenshot({path:`tests/screenshots/project-${id}.png`});
}
await page.setViewportSize({width:1440,height:860});
await page.goto(base);await page.evaluate(()=>document.fonts.ready);await page.screenshot({path:'tests/screenshots/project-zicmalen.png'});
await browser.close();
