import { siteConfig } from './site-config.js';

// Only call after an explicit user confirmation. No private credentials belong here.
// A server-side email adapter must validate/rate-limit input and send to the configured business inbox.
export async function sendContactMessage(details) {
  const endpoint = siteConfig.contact.endpoint;
  if (!endpoint) throw new Error('Direct email delivery is not configured. Please use your email app or WhatsApp.');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(details),
      signal: controller.signal,
    });
    const result = await response.json();
    if (!response.ok || result.success !== true) throw new Error('The email service did not confirm acceptance. Your message has not been confirmed as sent. Please use email or WhatsApp instead.');
    return { accepted: true };
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('The email service timed out. Delivery is unconfirmed. Please contact us directly.');
    throw error;
  } finally { clearTimeout(timer); }
}
