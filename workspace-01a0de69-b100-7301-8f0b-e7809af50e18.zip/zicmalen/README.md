# Zicmalen Web-built — Developer Portfolio Redesign

A complete visual/UI redesign of the existing Zicmalen Web-built website for Isaac Richard. Built with semantic HTML, custom CSS, vanilla JavaScript, Vite, and selectively bundled Lucide icons. No framework or external CDN is needed at runtime.

## Start / build

Requires Node.js 20.19+ or 22.12+.

```bash
npm ci
npm run dev
npm run build
npm run preview
```

Deploy the generated `dist/` directory to a static hosting provider. Asset paths assume deployment at the domain root. The development server binds to 0.0.0.0 and accepts the live-preview proxy hostname.

## Verified business contact

The single source of truth for frontend contact actions is `site-config.js`:

- Email: **Zicmalen@gmail.com**
- WhatsApp / phone: **+234 708 091 1672**
- WhatsApp international digits: **2347080911672**

WhatsApp links open `https://wa.me/2347080911672`. Phone and email links use `tel:` and `mailto:` respectively. The form preview creates encoded message drafts addressed to these verified contacts.

If changing contact details later, also update the static SEO structured data and initial HTML contact text (JavaScript synchronizes the rendered links and displayed details at runtime).

## Honest form delivery

**No direct email provider is connected by default.**

The frontend form includes name, email, phone number, optional business name, project type, and message. Submitting validates the inputs and opens a review dialog. The visitor can:

1. Open their email app with a prepared message to `Zicmalen@gmail.com`.
2. Open WhatsApp with the prepared enquiry.
3. Copy the message or download a text draft.

The page explicitly states that opening an app does not send a message. The visitor must press Send in that app. No success confirmation is invented. Form input is kept in page memory only, not saved to local storage or a database.

### Connecting an email backend later

`contact-service.js` contains the optional server adapter, separate from the form UI. Set `siteConfig.contact.endpoint` to a same-origin route (for example `/api/contact`) or an HTTPS endpoint configured for CORS. The UI then labels the delivery mode as EMAIL SERVICE and adds an explicit confirmation button in the review dialog.

The endpoint receives a JSON POST:

```json
{
  "name": "Visitor name",
  "email": "visitor@example.com",
  "phone": "+234 ...",
  "business": "Optional business name",
  "service": "Website Development",
  "message": "The project details"
}
```

Server requirements:

- Use an email provider on the server and keep credentials in server environment variables, never frontend source.
- Configure the recipient as `Zicmalen@gmail.com` server-side. Do not accept a caller-supplied destination.
- Validate and sanitize all input. Set the visitor's verified-format email as Reply-To, not as an untrusted From address.
- Apply rate limiting and spam protection. The frontend includes a basic honeypot but it is not a substitute for server-side protections.
- Only return HTTP 2xx with `{ "success": true }` after the email provider accepts the message.
- Return an error otherwise. The frontend handles timeouts, non-2xx responses, malformed JSON, and explicit failure without claiming delivery.
- Review the privacy notice, provider identity, and retention policy before enabling direct submission.

Even on acceptance the UI says the provider accepted the message, not that inbox delivery has been independently confirmed.

## Social accounts

The `socials` object in `site-config.js` contains empty, editable GitHub, LinkedIn, and Instagram entries. Add verified complete HTTPS URLs. Empty entries are hidden from the public interface, so there are no invented accounts or dead social buttons.

## Soft background music and compact mute control

The site includes **Quiet Circuit**, an original 48-second ambient-electronic loop created with additive synthesis for this project. It uses no third-party recordings, samples, streaming services, or embeds. The master level has been softened, with a 20% default playback level and gentle fade-in.

- On page load the site **attempts audible autoplay** through the browser's native audio element.
- Autoplay cannot be guaranteed: browsers and embedded-viewer permissions may block it. A blocked request leaves audio off and the speaker's accessible label explains that a tap is required.
- There are no global click handlers that unexpectedly enable sound, no silent-audio workarounds, and no attempt to bypass browser permission rules.
- The small bottom-left speaker icon mutes/pauses active music immediately. Clicking again resumes it. The adjacent small arrow opens volume settings.
- Desktop controls are about 66 px wide in total; the mobile mute target stays 44 px wide for usability. The full-width SOUND OFF text was replaced with an accessible icon and hidden state label.
- Music pauses on a hidden tab and does not unexpectedly restart while the visitor returns. A fresh page load attempts autoplay again. No listening preference is persisted.
- Volume uses native media gain during initial autoplay and a Web Audio gain node after interaction, including for iOS volume control.
- The approximately 258 KB local MP3 is embedded in the single-file export.

Configuration: `siteConfig.music` in `site-config.js`. Use `autoplay: false` for opt-in playback, `enabled: false` to remove the player, or adjust `defaultVolume`. Replace `src` only with audio you have permission to use. Implementation: `ambient-player.js`. Synthesis source: `tools/create-ambient.py` (Python + NumPy + SoundFile only needed to regenerate the MP3).

Run `node tests/music.mjs` with the dev server active. It tests both browser policies with browser launch flags: autoplay allowed and explicit user gesture required. Checks include actual playback progression, mute/pause, resuming, volume, blocked-playback messaging, the new branding, and compact responsive sizing. This test does not imply autoplay can be forced on real visitors' browsers.

## Brand assets

`public/brand/` includes interlocking W/Z vector monograms and horizontal wordmarks:

- White
- Electric blue / cyan
- White + electric blue
- Black for light backgrounds

The selected digital W/Z identity is built from sharp routed paths, a shared diagonal, deliberate negative-space channels, and square circuit terminals. The user-selected image direction was reconstructed into clean, editable vector polygons. The wordmark uses outlined Space Grotesk glyphs, so the horizontal SVGs do not depend on installed fonts. The same monogram powers the favicon and a dedicated social avatar. SVGs scale cleanly for business materials and social graphics. Transparent white variants should be displayed on a dark background. Transparent 1024px PNGs, a horizontal PNG, an Apple touch icon, and a dark social-avatar version are also included. Regenerate vectors with `python tools/create-brand.py` (requires fontTools). `wz-horizontal.svg` is the default white/blue horizontal lockup.

## Content integrity

- Isaac is explicitly described as a web developer in training.
- The profile is a custom initials-based developer card, not a fake portrait.
- The Zicmalen Web-built Website project is the actual implemented website.
- Food Sky Website and Nevada Sculpted Stay are self-initiated visual concepts, evolved from the earlier restaurant and architectural interface studies.
- City Checkout Flow is a new UI concept. Pricing is clearly illustrative; no transaction or conversion result is claimed.
- Zicmalen AI Project is a planned product represented by an HTML/CSS visual prototype. No AI service, automation engine, or external API is connected.
- Project technology tags describe the actual implementation of the site or visual study. The real site uses HTML/CSS/JavaScript, not React/Next.js. Prototype screenshots are produced from HTML/CSS source in `project-studies/`.
- The original three illustrative reviews are preserved verbatim and labeled as samples, not real client endorsements. No client identities or new testimonials are fabricated.
- Statistics describe actual service/package counts, mobile-first thinking, and one-to-one communication—not fabricated clients, revenue, conversion lifts, or delivery history.
- Packages preserve the original scope, including contact forms, WhatsApp, SEO, analytics, AI integration, and maintenance. These are offered scopes, not claims that all those services run on this site.
- Tools such as React, Next.js, Tailwind, Python, and AI are labeled EXPLORING rather than asserting unsupported expertise.

## Main files

- `index.html` — semantic page content, metadata, SEO structured data.
- `style.css` — near-black/navy design, blue/cyan accents, controlled red markers, responsive layout.
- `main.js` — project/service/package content, dialogs, filters, form review, navigation, reveal/count animations.
- `site-config.js` — editable verified contacts, social placeholders, optional email endpoint.
- `contact-service.js` — optional direct email adapter.
- `fonts.css`, `public/fonts/` — self-hosted Manrope and Space Grotesk.
- `public/images/` — optimized project screenshots and illustrative portfolio imagery.
- `public/brand/` — SVG logo variants.
- `project-studies/` — static visual prototypes used only to produce portfolio screenshots; not live applications or functional booking/payment/AI products.
- `tools/create-studies.py` — regenerates the design-study HTML.
- `tools/render-projects.mjs` — renders screenshots using Playwright.
- `export-standalone.py` — embeds all production assets in a single offline HTML file.
- `tests/verify.mjs` — responsive/functionality checks.
- `tests/adapter.mjs` — network-mocked email adapter acceptance/failure checks; no real email is sent.

## Testing

With the dev server running:

```bash
npx playwright install chromium
npx playwright install-deps chromium
node tests/verify.mjs
node tests/adapter.mjs
```

Checks cover all sections, 14 widths from 320px to 1920px, images, internal anchors, email/phone/WhatsApp destinations, all project dialogs, filters, package selection, form validation, review/download, privacy, mobile navigation, and runtime errors. The reduced-motion preference is supported. Dynamic dialogs use native modal behavior and return focus to the initiating control.

## Offline HTML export

```bash
npm run build
python export-standalone.py
```

`Zicmalen-Web-built.html` contains fonts, styles, scripts, logo assets, project previews, and the original music. Rebuild and re-export after editing. Its base website works without an internet connection; sending through email or WhatsApp requires the relevant app/service. Sandboxed file viewers may block external apps, clipboard access, or file downloads; use the live preview or download the HTML and open it in a normal browser for the full experience.

## SEO and publication

The requested title and meta description, Open Graph title/description, semantic section headings, favicon, and ProfessionalService structured data are included. Add a canonical URL, a sitemap, and an absolute social-sharing image URL once the real publication domain is chosen. None is invented. Review actual testimonials/projects before replacing sample content. No analytics trackers or third-party network assets load by default.

## Asset credits

Manrope and Space Grotesk are open-source Google Fonts. Lucide icons are ISC-licensed. License texts are included in `licenses/`. Illustrative Unsplash photos are used only within concept-project previews: restaurant `photo-1414235077428-338989a2e8c0`, interior `photo-1600607687939-ce8a6c25118c`. There are no office-stock photos in the main developer identity.
